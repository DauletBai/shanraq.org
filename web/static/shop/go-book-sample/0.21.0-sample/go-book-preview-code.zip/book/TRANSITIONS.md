# Точные изменения контрольных точек

Пути ниже считаются от папки соответствующей главы в book/examples.
Сначала прочитайте объяснение главы. Это перечень различий исходников, а не команда удаления вашей работы.
Сохраните предыдущую папку; задания выполняйте в отдельной копии. Базы, ключи и покупки не переносите автоматически.
В каждой новой контрольной точке свой путь module в go.mod и такое же начало локальных импортов.
Изменения только этого префикса не перечисляются как изменения поведения. Остальные файлы перечислены полностью.

## 2. Книга появляется в терминале

`book/examples/02-first-program`

Создать:

- `go.mod`
- `main.go`
- `stdout.txt`

## 3. Название, цена и состояние книги

`book/examples/03-values`

Создать:

- `labs/01-values/main.go`
- `labs/01-values/stdout.txt`

Заменить содержимое:

- `main.go`
- `stdout.txt`

## 4. Какие издания можно показать

`book/examples/04-conditions`

Создать:

- `labs/01-choices/main.go`
- `labs/01-choices/stdout.txt`
- `labs/02-loops/main.go`
- `labs/02-loops/stdout.txt`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `labs/01-values/main.go`
- `labs/01-values/stdout.txt`

## 5. Правило цены и первый тест

`book/examples/05-functions`

Создать:

- `labs/01-functions/main.go`
- `labs/01-functions/stdout.txt`
- `main_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `labs/01-choices/main.go`
- `labs/01-choices/stdout.txt`
- `labs/02-loops/main.go`
- `labs/02-loops/stdout.txt`

## 6. Сколько букв в названии книги

`book/examples/06-strings`

Создать:

- `labs/01-text/main.go`
- `labs/01-text/stdout.txt`
- `title.go`
- `title_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `labs/01-functions/main.go`
- `labs/01-functions/stdout.txt`
- `main_test.go`

## 7. Каталог: список, массив и словарь

`book/examples/07-catalog`

Создать:

- `catalog.go`
- `catalog_test.go`
- `labs/01-arrays/main.go`
- `labs/01-arrays/stdout.txt`
- `labs/02-slices/main.go`
- `labs/02-slices/stdout.txt`
- `labs/03-maps/main.go`
- `labs/03-maps/stdout.txt`
- `sharing_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `labs/01-text/main.go`
- `labs/01-text/stdout.txt`

## 8. Книга как значение: структуры, методы и указатели

`book/examples/08-books`

Создать:

- `book.go`
- `book_test.go`
- `labs/01-structs/main.go`
- `labs/01-structs/stdout.txt`
- `labs/02-pointers/main.go`
- `labs/02-pointers/stdout.txt`
- `labs/03-methods/main.go`
- `labs/03-methods/stdout.txt`
- `pricing.go`
- `pricing_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `catalog.go`
- `catalog_test.go`
- `labs/01-arrays/main.go`
- `labs/01-arrays/stdout.txt`
- `labs/02-slices/main.go`
- `labs/02-slices/stdout.txt`
- `labs/03-maps/main.go`
- `labs/03-maps/stdout.txt`
- `sharing_test.go`

## 9. Файл не открылся: ошибки и освобождение ресурсов

`book/examples/09-errors`

Создать:

- `defer_test.go`
- `file.go`
- `file_test.go`
- `labs/01-functions/main.go`
- `labs/01-functions/stdout.txt`
- `labs/02-defer/main.go`
- `labs/02-defer/stdout.txt`
- `labs/03-errors/main.go`
- `labs/03-errors/stdout.txt`
- `title.txt`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `labs/01-structs/main.go`
- `labs/01-structs/stdout.txt`
- `labs/02-pointers/main.go`
- `labs/02-pointers/stdout.txt`
- `labs/03-methods/main.go`
- `labs/03-methods/stdout.txt`

## 10. Пакеты: у каждого правила свой адрес

`book/examples/10-packages`

Создать:

- `cmd/shop/main.go`
- `internal/catalog/book.go`
- `internal/catalog/book_test.go`
- `internal/catalog/pricing.go`
- `internal/catalog/pricing_test.go`
- `internal/catalog/title.go`
- `internal/catalog/title_test.go`
- `internal/titlefile/file.go`
- `internal/titlefile/file_test.go`
- `labs/01-package/greeting/message.go`
- `labs/01-package/main.go`
- `labs/01-package/stdout.txt`

Заменить содержимое:

- `go.mod`
- `title.txt`

Не переносить из прежней папки:

- `book.go`
- `book_test.go`
- `defer_test.go`
- `file.go`
- `file_test.go`
- `labs/01-functions/main.go`
- `labs/01-functions/stdout.txt`
- `labs/02-defer/main.go`
- `labs/02-defer/stdout.txt`
- `labs/03-errors/main.go`
- `labs/03-errors/stdout.txt`
- `main.go`
- `pricing.go`
- `pricing_test.go`
- `title.go`
- `title_test.go`

## 11. Каталог отвечает браузеру

`book/examples/11-http`

Создать:

- `internal/catalog/list.go`
- `internal/web/web.go`
- `internal/web/web_test.go`
- `labs/01-handler/main.go`
- `labs/01-handler/stdout.txt`

Заменить содержимое:

- `cmd/shop/main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `labs/01-package/greeting/message.go`
- `labs/01-package/main.go`
- `labs/01-package/stdout.txt`

## 12. HTML-шаблон превращает каталог в страницу

`book/examples/12-templates`

Создать:

- `internal/web/brand.go`
- `internal/web/brand_test.go`
- `internal/web/footer_test.go`
- `internal/web/template_test.go`
- `internal/web/templates.go`
- `labs/01-template/main.go`
- `labs/01-template/stdout.txt`
- `labs/02-layout/main.go`
- `labs/02-layout/stdout.txt`
- `web/assets.go`
- `web/static/brand/apple-touch-icon.png`
- `web/static/brand/favicon-16.png`
- `web/static/brand/favicon-32.png`
- `web/static/brand/favicon.ico`
- `web/static/brand/gopher-cart.png`
- `web/static/css/style.css`
- `web/static/images/.gitkeep`
- `web/static/js/.gitkeep`
- `web/templates/layouts/base.html`
- `web/templates/pages/home.html`
- `web/templates/partials/footer.html`
- `web/templates/partials/header.html`

Заменить содержимое:

- `internal/web/web.go`

Не переносить из прежней папки:

- `labs/01-handler/main.go`
- `labs/01-handler/stdout.txt`

