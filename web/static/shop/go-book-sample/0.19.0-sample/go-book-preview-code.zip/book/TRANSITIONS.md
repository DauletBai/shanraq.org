# Точные изменения контрольных точек

Пути ниже считаются от папки соответствующей главы в book/examples.
Сначала прочитайте объяснение главы. Это перечень различий исходников, а не команда удаления вашей работы.
Сохраните предыдущую папку; задания выполняйте в отдельной копии. Базы, ключи и покупки не переносите автоматически.
В каждой новой контрольной точке свой путь module в go.mod и такое же начало локальных импортов.
Изменения только этого префикса не перечисляются как изменения поведения. Остальные файлы перечислены полностью.

## 2. Книга появляется в терминале

`book/examples/02-first-program`

Создать:

- `go.mod`
- `main.go`
- `stdout.txt`

## 3. Название, цена и состояние книги

`book/examples/03-values`

Заменить содержимое:

- `main.go`
- `stdout.txt`

## 4. Какие издания можно показать

`book/examples/04-conditions`

Заменить содержимое:

- `main.go`
- `stdout.txt`

## 5. Правило цены и первый тест

`book/examples/05-functions`

Создать:

- `main_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

## 6. Сколько букв в названии книги

`book/examples/06-strings`

Создать:

- `title.go`
- `title_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `main_test.go`

## 7. Каталог: список, массив и словарь

`book/examples/07-catalog`

Создать:

- `catalog.go`
- `catalog_test.go`
- `sharing_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

## 8. Книга как значение: структуры, методы и указатели

`book/examples/08-books`

Создать:

- `book.go`
- `book_test.go`
- `pricing.go`
- `pricing_test.go`

Заменить содержимое:

- `main.go`
- `stdout.txt`

Не переносить из прежней папки:

- `catalog.go`
- `catalog_test.go`
- `sharing_test.go`

## 9. Файл не открылся: ошибки и освобождение ресурсов

`book/examples/09-errors`

Создать:

- `defer_test.go`
- `file.go`
- `file_test.go`
- `title.txt`

Заменить содержимое:

- `main.go`
- `stdout.txt`

## 10. Пакеты: у каждого правила свой адрес

`book/examples/10-packages`

Создать:

- `cmd/shop/main.go`
- `internal/catalog/book.go`
- `internal/catalog/book_test.go`
- `internal/catalog/pricing.go`
- `internal/catalog/pricing_test.go`
- `internal/catalog/title.go`
- `internal/catalog/title_test.go`
- `internal/titlefile/file.go`
- `internal/titlefile/file_test.go`

Заменить содержимое:

- `go.mod`
- `title.txt`

Не переносить из прежней папки:

- `book.go`
- `book_test.go`
- `defer_test.go`
- `file.go`
- `file_test.go`
- `main.go`
- `pricing.go`
- `pricing_test.go`
- `title.go`
- `title_test.go`

## 11. Каталог отвечает браузеру

`book/examples/11-http`

Создать:

- `internal/catalog/list.go`
- `internal/web/web.go`
- `internal/web/web_test.go`

Заменить содержимое:

- `cmd/shop/main.go`
- `stdout.txt`

## 12. HTML-шаблон превращает каталог в страницу

`book/examples/12-templates`

Создать:

- `internal/web/brand.go`
- `internal/web/brand_test.go`
- `internal/web/footer_test.go`
- `internal/web/template_test.go`
- `internal/web/templates.go`
- `web/assets.go`
- `web/static/brand/apple-touch-icon.png`
- `web/static/brand/favicon-16.png`
- `web/static/brand/favicon-32.png`
- `web/static/brand/favicon.ico`
- `web/static/brand/gopher-cart.png`
- `web/static/css/style.css`
- `web/static/images/.gitkeep`
- `web/static/js/.gitkeep`
- `web/templates/layouts/base.html`
- `web/templates/pages/home.html`
- `web/templates/partials/footer.html`
- `web/templates/partials/header.html`

Заменить содержимое:

- `internal/web/web.go`

